import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Product } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ListingModalProps {
  product: Product | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ListingModal({ product, open, onOpenChange }: ListingModalProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    listingTitle: "",
    listingPrice: "",
    buyItNowPrice: "",
    condition: "New",
    ebayCategory: "",
  });

  // Set initial form data when product changes
  useState(() => {
    if (product) {
      const ebayPrice = parseFloat(product.ebayEstimatedPrice || '0');
      setFormData({
        listingTitle: product.title,
        listingPrice: ebayPrice > 0 ? ebayPrice.toFixed(2) : "",
        buyItNowPrice: ebayPrice > 0 ? (ebayPrice + 20).toFixed(2) : "",
        condition: "New",
        ebayCategory: product.category || "",
      });
    }
  });

  const listingMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/list-on-ebay", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Listing Created",
        description: "Your eBay listing draft has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ebay-listings"] });
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Create Listing",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!product) return;

    listingMutation.mutate({
      productId: product.id,
      ...formData,
      listingPrice: parseFloat(formData.listingPrice),
      buyItNowPrice: formData.buyItNowPrice ? parseFloat(formData.buyItNowPrice) : null,
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (!product) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create eBay Listing</DialogTitle>
          <DialogDescription>
            Configure your eBay listing details before publishing
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="listing-title">Listing Title</Label>
            <Input
              id="listing-title"
              value={formData.listingTitle}
              onChange={(e) => handleInputChange("listingTitle", e.target.value)}
              placeholder="Enter listing title"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="starting-price">Starting Price ($)</Label>
              <Input
                id="starting-price"
                type="number"
                step="0.01"
                min="0"
                value={formData.listingPrice}
                onChange={(e) => handleInputChange("listingPrice", e.target.value)}
                placeholder="0.00"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="buy-it-now-price">Buy It Now Price ($)</Label>
              <Input
                id="buy-it-now-price"
                type="number"
                step="0.01"
                min="0"
                value={formData.buyItNowPrice}
                onChange={(e) => handleInputChange("buyItNowPrice", e.target.value)}
                placeholder="0.00"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              rows={4}
              value={product.description || ""}
              placeholder="Enter product description"
              readOnly
              className="resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                value={formData.ebayCategory}
                onChange={(e) => handleInputChange("ebayCategory", e.target.value)}
                placeholder="Product category"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="condition">Condition</Label>
              <Select
                value={formData.condition}
                onValueChange={(value) => handleInputChange("condition", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="New">New</SelectItem>
                  <SelectItem value="Used">Used</SelectItem>
                  <SelectItem value="Refurbished">Refurbished</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="flex justify-end space-x-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={listingMutation.isPending}
            >
              {listingMutation.isPending ? "Creating..." : "Create Listing"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
