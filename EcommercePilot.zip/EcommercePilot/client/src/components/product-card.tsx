import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Eye, ExternalLink } from "lucide-react";
import { Product } from "@shared/schema";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  onViewDetails?: (product: Product) => void;
  onListOnEbay?: (product: Product) => void;
}

export function ProductCard({ product, onViewDetails, onListOnEbay }: ProductCardProps) {
  const profit = parseFloat(product.estimatedProfit || '0');
  const isProfitable = profit > 0;
  const amazonPrice = parseFloat(product.amazonPrice);
  const ebayPrice = parseFloat(product.ebayEstimatedPrice || '0');

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="aspect-square bg-gray-100 rounded-lg mb-4 flex items-center justify-center overflow-hidden">
          {product.images && product.images.length > 0 ? (
            <img
              src={product.images[0]}
              alt={product.title}
              className="w-full h-full object-cover rounded-lg"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
              }}
            />
          ) : (
            <div className="w-full h-full bg-gray-200 rounded-lg flex items-center justify-center">
              <span className="text-gray-400 text-sm">No Image</span>
            </div>
          )}
        </div>
        
        <div className="space-y-3">
          <h3 className="font-medium text-gray-900 line-clamp-2 text-sm leading-tight">
            {product.title}
          </h3>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Amazon</span>
              <span className="font-semibold text-gray-900">
                ${amazonPrice.toFixed(2)}
              </span>
            </div>
            
            {ebayPrice > 0 && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">eBay Est.</span>
                <span className="font-semibold text-gray-900">
                  ${ebayPrice.toFixed(2)}
                </span>
              </div>
            )}
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Profit</span>
              <Badge
                variant={isProfitable ? "default" : "destructive"}
                className={cn(
                  "text-xs font-semibold",
                  isProfitable 
                    ? "bg-green-100 text-green-800 hover:bg-green-100" 
                    : "bg-red-100 text-red-800 hover:bg-red-100"
                )}
              >
                {profit >= 0 ? '+' : ''}${profit.toFixed(2)}
              </Badge>
            </div>
          </div>
          
          <div className="flex gap-2 pt-2">
            {isProfitable ? (
              <Button
                size="sm"
                className="flex-1 text-xs"
                onClick={() => onListOnEbay?.(product)}
              >
                List on eBay
              </Button>
            ) : (
              <Button
                size="sm"
                variant="secondary"
                className="flex-1 text-xs"
                disabled
              >
                Not Profitable
              </Button>
            )}
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => onViewDetails?.(product)}
              className="px-3"
            >
              <Eye className="h-3 w-3" />
            </Button>
          </div>
          
          {product.rating && (
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>⭐ {product.rating}</span>
              {product.reviewCount && (
                <span>({product.reviewCount} reviews)</span>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
