import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings as SettingsIcon, 
  User, 
  Key, 
  Bell, 
  Shield, 
  ExternalLink,
  CheckCircle,
  AlertCircle,
  Save
} from "lucide-react";

export default function Settings() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [profileData, setProfileData] = useState({
    username: user?.username || "",
    email: user?.email || "",
  });

  const [notificationSettings, setNotificationSettings] = useState({
    priceDropAlerts: true,
    priceIncreaseAlerts: true,
    outOfStockAlerts: true,
    emailNotifications: true,
  });

  const [apiKeys, setApiKeys] = useState({
    ebayClientId: "",
    ebayClientSecret: "",
    ebayAccessToken: "",
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof profileData) => {
      const res = await apiRequest("PATCH", "/api/user", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(profileData);
  };

  const handleProfileInputChange = (field: string, value: string) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  const handleNotificationChange = (field: string, value: boolean) => {
    setNotificationSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleApiKeyChange = (field: string, value: string) => {
    setApiKeys(prev => ({ ...prev, [field]: value }));
  };

  const connectEbayAccount = () => {
    // In a real implementation, this would redirect to eBay OAuth
    toast({
      title: "eBay Connection",
      description: "eBay OAuth integration coming soon!",
    });
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
              <p className="text-sm text-gray-500">Manage your account and application preferences</p>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-8">
          <div className="max-w-4xl mx-auto">
            <Tabs defaultValue="profile" className="space-y-6">
              <TabsList>
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="ebay">eBay Integration</TabsTrigger>
                <TabsTrigger value="notifications">Notifications</TabsTrigger>
                <TabsTrigger value="security">Security</TabsTrigger>
              </TabsList>

              <TabsContent value="profile" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Profile Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleProfileSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="username">Username</Label>
                          <Input
                            id="username"
                            value={profileData.username}
                            onChange={(e) => handleProfileInputChange("username", e.target.value)}
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="email">Email Address</Label>
                          <Input
                            id="email"
                            type="email"
                            value={profileData.email}
                            onChange={(e) => handleProfileInputChange("email", e.target.value)}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Account Created</Label>
                        <p className="text-sm text-gray-600">
                          {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'Unknown'}
                        </p>
                      </div>

                      <Separator />

                      <div className="flex justify-end">
                        <Button
                          type="submit"
                          disabled={updateProfileMutation.isPending}
                        >
                          {updateProfileMutation.isPending ? (
                            <>
                              <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                              Saving...
                            </>
                          ) : (
                            <>
                              <Save className="h-4 w-4 mr-2" />
                              Save Changes
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="ebay" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ExternalLink className="h-5 w-5" />
                      eBay Account Connection
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                          <ExternalLink className="h-5 w-5 text-yellow-600" />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">eBay Account</h3>
                          <p className="text-sm text-gray-500">
                            {user?.ebayAccessToken ? 'Connected' : 'Not connected'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {user?.ebayAccessToken ? (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Connected
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Not Connected
                          </Badge>
                        )}
                        <Button
                          onClick={connectEbayAccount}
                          variant={user?.ebayAccessToken ? "outline" : "default"}
                        >
                          {user?.ebayAccessToken ? "Reconnect" : "Connect eBay"}
                        </Button>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                        <div className="text-sm">
                          <p className="font-medium text-blue-900 mb-1">eBay Integration Benefits:</p>
                          <ul className="text-blue-800 space-y-1">
                            <li>• Automatically list products on eBay</li>
                            <li>• Sync inventory and pricing</li>
                            <li>• Track sales and performance</li>
                            <li>• Manage orders from ListPilot</li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-4">
                      <h4 className="font-medium text-gray-900">API Configuration (Advanced)</h4>
                      <div className="grid grid-cols-1 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="ebay-client-id">eBay Client ID</Label>
                          <Input
                            id="ebay-client-id"
                            type="password"
                            placeholder="Enter your eBay Client ID"
                            value={apiKeys.ebayClientId}
                            onChange={(e) => handleApiKeyChange("ebayClientId", e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="ebay-client-secret">eBay Client Secret</Label>
                          <Input
                            id="ebay-client-secret"
                            type="password"
                            placeholder="Enter your eBay Client Secret"
                            value={apiKeys.ebayClientSecret}
                            onChange={(e) => handleApiKeyChange("ebayClientSecret", e.target.value)}
                          />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="notifications" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Bell className="h-5 w-5" />
                      Notification Preferences
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">Price Drop Alerts</h4>
                          <p className="text-sm text-gray-500">Get notified when product prices decrease</p>
                        </div>
                        <Switch
                          checked={notificationSettings.priceDropAlerts}
                          onCheckedChange={(checked) => handleNotificationChange("priceDropAlerts", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">Price Increase Alerts</h4>
                          <p className="text-sm text-gray-500">Get notified when product prices increase</p>
                        </div>
                        <Switch
                          checked={notificationSettings.priceIncreaseAlerts}
                          onCheckedChange={(checked) => handleNotificationChange("priceIncreaseAlerts", checked)}
                        />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">Out of Stock Alerts</h4>
                          <p className="text-sm text-gray-500">Get notified when products go out of stock</p>
                        </div>
                        <Switch
                          checked={notificationSettings.outOfStockAlerts}
                          onCheckedChange={(checked) => handleNotificationChange("outOfStockAlerts", checked)}
                        />
                      </div>

                      <Separator />

                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">Email Notifications</h4>
                          <p className="text-sm text-gray-500">Receive alerts via email</p>
                        </div>
                        <Switch
                          checked={notificationSettings.emailNotifications}
                          onCheckedChange={(checked) => handleNotificationChange("emailNotifications", checked)}
                        />
                      </div>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium text-gray-900 mb-2">Notification Schedule</h4>
                      <p className="text-sm text-gray-600">
                        Monitoring checks run every 30 minutes. You'll receive alerts immediately when significant 
                        price changes ({'>'} 5%) are detected.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="security" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      Security Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Change Password</h4>
                        <p className="text-sm text-gray-500 mb-4">
                          Update your password to keep your account secure.
                        </p>
                        <Button variant="outline">
                          <Key className="h-4 w-4 mr-2" />
                          Change Password
                        </Button>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Session Management</h4>
                        <p className="text-sm text-gray-500 mb-4">
                          Manage your active sessions and logged-in devices.
                        </p>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                            <div>
                              <p className="text-sm font-medium text-gray-900">Current Session</p>
                              <p className="text-xs text-gray-500">Your current browser session</p>
                            </div>
                            <Badge className="bg-green-100 text-green-800">Active</Badge>
                          </div>
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Data Export</h4>
                        <p className="text-sm text-gray-500 mb-4">
                          Download your data including scraped products and listings.
                        </p>
                        <Button variant="outline">
                          Export My Data
                        </Button>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="font-medium text-gray-900 mb-2 text-red-600">Danger Zone</h4>
                        <p className="text-sm text-gray-500 mb-4">
                          Permanently delete your account and all associated data.
                        </p>
                        <Button variant="destructive">
                          Delete Account
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}
