import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  List, 
  Edit, 
  Trash2, 
  ExternalLink, 
  Eye, 
  Search,
  Plus,
  DollarSign,
  Calendar,
  Package
} from "lucide-react";
import { EbayListing } from "@shared/schema";

export default function Listings() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Fetch eBay listings
  const { data: listings = [], isLoading } = useQuery<EbayListing[]>({
    queryKey: ["/api/ebay-listings"],
  });

  // Delete listing mutation
  const deleteMutation = useMutation({
    mutationFn: async (listingId: number) => {
      await apiRequest("DELETE", `/api/ebay-listings/${listingId}`);
    },
    onSuccess: () => {
      toast({
        title: "Listing deleted",
        description: "The listing has been successfully deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ebay-listings"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete listing",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update listing status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({ listingId, status }: { listingId: number; status: string }) => {
      const res = await apiRequest("PATCH", `/api/ebay-listings/${listingId}`, {
        listingStatus: status,
      });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Status updated",
        description: "The listing status has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/ebay-listings"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update status",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter listings
  const filteredListings = listings.filter(listing => {
    const matchesSearch = listing.listingTitle.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || listing.listingStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { variant: "secondary" as const, label: "Draft" },
      active: { variant: "default" as const, label: "Active" },
      sold: { variant: "default" as const, label: "Sold", className: "bg-green-100 text-green-800" },
      ended: { variant: "destructive" as const, label: "Ended" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.draft;
    
    return (
      <Badge variant={config.variant} className={config.className || ""}>
        {config.label}
      </Badge>
    );
  };

  const getStatusCounts = () => {
    return {
      all: listings.length,
      draft: listings.filter(l => l.listingStatus === 'draft').length,
      active: listings.filter(l => l.listingStatus === 'active').length,
      sold: listings.filter(l => l.listingStatus === 'sold').length,
      ended: listings.filter(l => l.listingStatus === 'ended').length,
    };
  };

  const statusCounts = getStatusCounts();

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">eBay Listings</h1>
              <p className="text-sm text-gray-500">Manage your eBay listings and track their performance</p>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <ExternalLink className="h-4 w-4 mr-2" />
                View on eBay
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-8 space-y-6">
          {/* Filters */}
          <Card>
            <CardContent className="p-6">
              <div className="flex gap-4 items-center">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search listings..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All ({statusCounts.all})</SelectItem>
                    <SelectItem value="draft">Draft ({statusCounts.draft})</SelectItem>
                    <SelectItem value="active">Active ({statusCounts.active})</SelectItem>
                    <SelectItem value="sold">Sold ({statusCounts.sold})</SelectItem>
                    <SelectItem value="ended">Ended ({statusCounts.ended})</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Listings */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Your Listings ({filteredListings.length})</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Bulk Actions
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 flex-1">
                          <Skeleton className="w-16 h-16" />
                          <div className="space-y-2 flex-1">
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-3 w-1/2" />
                            <Skeleton className="h-3 w-1/4" />
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <Skeleton className="h-6 w-16" />
                          <Skeleton className="h-8 w-20" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredListings.length > 0 ? (
                <div className="space-y-4">
                  {filteredListings.map((listing) => (
                    <div key={listing.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 flex-1">
                          <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                            <Package className="h-8 w-8 text-gray-400" />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-gray-900 line-clamp-1">
                              {listing.listingTitle}
                            </h3>
                            <div className="flex items-center space-x-4 mt-1 text-sm text-gray-500">
                              <span className="flex items-center">
                                <DollarSign className="h-3 w-3 mr-1" />
                                ${parseFloat(listing.listingPrice).toFixed(2)}
                              </span>
                              {listing.buyItNowPrice && (
                                <span className="flex items-center">
                                  BIN: ${parseFloat(listing.buyItNowPrice).toFixed(2)}
                                </span>
                              )}
                              <span className="flex items-center">
                                <Calendar className="h-3 w-3 mr-1" />
                                {new Date(listing.createdAt).toLocaleDateString()}
                              </span>
                            </div>
                            <div className="flex items-center space-x-2 mt-2">
                              {getStatusBadge(listing.listingStatus)}
                              <Badge variant="outline" className="text-xs">
                                {listing.condition}
                              </Badge>
                              {listing.ebayCategory && (
                                <Badge variant="outline" className="text-xs">
                                  {listing.ebayCategory}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          {listing.listingStatus === 'draft' && (
                            <Button
                              size="sm"
                              onClick={() => updateStatusMutation.mutate({ 
                                listingId: listing.id, 
                                status: 'active' 
                              })}
                              disabled={updateStatusMutation.isPending}
                            >
                              Publish
                            </Button>
                          )}
                          
                          {listing.listingStatus === 'active' && listing.ebayItemId && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => window.open(`https://www.ebay.com/itm/${listing.ebayItemId}`, '_blank')}
                            >
                              <ExternalLink className="h-3 w-3 mr-1" />
                              View
                            </Button>
                          )}
                          
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              // Navigate to edit listing
                              console.log("Edit listing:", listing.id);
                            }}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteMutation.mutate(listing.id)}
                            disabled={deleteMutation.isPending}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <List className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {searchQuery || statusFilter !== "all" ? "No listings found" : "No listings yet"}
                  </h3>
                  <p className="text-gray-500 mb-4">
                    {searchQuery || statusFilter !== "all" 
                      ? "Try adjusting your search or filter criteria."
                      : "Create your first eBay listing from a scraped product."
                    }
                  </p>
                  {!searchQuery && statusFilter === "all" && (
                    <Button onClick={() => window.location.href = "/scraper"}>
                      <Plus className="h-4 w-4 mr-2" />
                      Start with Product Scraper
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          {listings.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-900">{statusCounts.draft}</p>
                    <p className="text-sm text-gray-500">Draft Listings</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-primary">{statusCounts.active}</p>
                    <p className="text-sm text-gray-500">Active Listings</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-profit">{statusCounts.sold}</p>
                    <p className="text-sm text-gray-500">Sold Items</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-600">
                      ${listings
                        .filter(l => l.listingStatus === 'sold')
                        .reduce((sum, l) => sum + parseFloat(l.listingPrice), 0)
                        .toFixed(2)}
                    </p>
                    <p className="text-sm text-gray-500">Total Sales</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
