import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Calculator, TrendingUp, TrendingDown, DollarSign, Percent, AlertCircle } from "lucide-react";

interface ProfitData {
  amazonPrice: number;
  ebayEstimatedPrice: number;
  ebayFees: number;
  paypalFees: number;
  shippingCost: number;
  totalCosts: number;
  estimatedProfit: number;
  profitMargin: number;
  isProfitable: boolean;
}

export default function ProfitAnalyzer() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    amazonPrice: "",
    ebayPrice: "",
    shippingCost: "5.99",
    customEbayFeeRate: "",
  });
  const [profitData, setProfitData] = useState<ProfitData | null>(null);

  // Calculate profit mutation
  const calculateMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const res = await apiRequest("POST", "/api/check-ebay-profit", {
        amazonPrice: data.amazonPrice,
        ebayPrice: data.ebayPrice,
        shippingCost: data.shippingCost || undefined,
        customEbayFeeRate: data.customEbayFeeRate || undefined,
      });
      return await res.json();
    },
    onSuccess: (data: ProfitData) => {
      setProfitData(data);
      toast({
        title: "Profit calculated successfully!",
        description: `${data.isProfitable ? 'Profitable' : 'Not profitable'} - ${data.isProfitable ? '+' : ''}$${data.estimatedProfit.toFixed(2)}`,
        variant: data.isProfitable ? "default" : "destructive",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Calculation failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.amazonPrice || !formData.ebayPrice) {
      toast({
        title: "Missing information",
        description: "Please enter both Amazon and eBay prices.",
        variant: "destructive",
      });
      return;
    }
    calculateMutation.mutate(formData);
  };

  const clearForm = () => {
    setFormData({
      amazonPrice: "",
      ebayPrice: "",
      shippingCost: "5.99",
      customEbayFeeRate: "",
    });
    setProfitData(null);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Profit Analyzer</h1>
              <p className="text-sm text-gray-500">Calculate profit margins for your Amazon to eBay arbitrage</p>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-8">
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Calculator Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Profit Calculator
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCalculate} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="amazon-price">Amazon Price ($)</Label>
                      <Input
                        id="amazon-price"
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="0.00"
                        value={formData.amazonPrice}
                        onChange={(e) => handleInputChange("amazonPrice", e.target.value)}
                        required
                      />
                      <p className="text-xs text-gray-500">The price you'll pay on Amazon</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="ebay-price">eBay Selling Price ($)</Label>
                      <Input
                        id="ebay-price"
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="0.00"
                        value={formData.ebayPrice}
                        onChange={(e) => handleInputChange("ebayPrice", e.target.value)}
                        required
                      />
                      <p className="text-xs text-gray-500">The price you'll sell for on eBay</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="shipping-cost">Shipping Cost ($)</Label>
                      <Input
                        id="shipping-cost"
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="5.99"
                        value={formData.shippingCost}
                        onChange={(e) => handleInputChange("shippingCost", e.target.value)}
                      />
                      <p className="text-xs text-gray-500">Estimated shipping cost (default: $5.99)</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="ebay-fee-rate">Custom eBay Fee Rate (%)</Label>
                      <Input
                        id="ebay-fee-rate"
                        type="number"
                        step="0.1"
                        min="0"
                        max="20"
                        placeholder="12.9"
                        value={formData.customEbayFeeRate}
                        onChange={(e) => handleInputChange("customEbayFeeRate", e.target.value)}
                      />
                      <p className="text-xs text-gray-500">Optional: Override default eBay fee (12.9%)</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button
                      type="submit"
                      disabled={calculateMutation.isPending}
                      className="flex-1"
                    >
                      {calculateMutation.isPending ? (
                        <>
                          <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                          Calculating...
                        </>
                      ) : (
                        <>
                          <Calculator className="h-4 w-4 mr-2" />
                          Calculate Profit
                        </>
                      )}
                    </Button>
                    <Button type="button" variant="outline" onClick={clearForm}>
                      Clear
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* Results */}
            {profitData && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Profit Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      {profitData.isProfitable ? (
                        <TrendingUp className="h-5 w-5 text-profit" />
                      ) : (
                        <TrendingDown className="h-5 w-5 text-loss" />
                      )}
                      Profit Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Status</span>
                      <Badge
                        variant={profitData.isProfitable ? "default" : "destructive"}
                        className={
                          profitData.isProfitable 
                            ? "bg-green-100 text-green-800 hover:bg-green-100" 
                            : "bg-red-100 text-red-800 hover:bg-red-100"
                        }
                      >
                        {profitData.isProfitable ? "Profitable" : "Not Profitable"}
                      </Badge>
                    </div>

                    <Separator />

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Estimated Profit</span>
                        <span className={`font-bold text-lg ${profitData.isProfitable ? 'text-profit' : 'text-loss'}`}>
                          {profitData.estimatedProfit >= 0 ? '+' : ''}${profitData.estimatedProfit.toFixed(2)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Profit Margin</span>
                        <span className={`font-semibold ${profitData.isProfitable ? 'text-profit' : 'text-loss'}`}>
                          {profitData.profitMargin.toFixed(1)}%
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Revenue</span>
                        <span className="font-semibold text-gray-900">
                          ${profitData.ebayEstimatedPrice.toFixed(2)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Total Costs</span>
                        <span className="font-semibold text-gray-900">
                          ${profitData.totalCosts.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Cost Breakdown */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <DollarSign className="h-5 w-5" />
                      Cost Breakdown
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Amazon Price</span>
                        <span className="font-semibold text-gray-900">
                          ${profitData.amazonPrice.toFixed(2)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">eBay Fees</span>
                        <span className="font-semibold text-gray-900">
                          ${profitData.ebayFees.toFixed(2)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">PayPal Fees</span>
                        <span className="font-semibold text-gray-900">
                          ${profitData.paypalFees.toFixed(2)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Shipping Cost</span>
                        <span className="font-semibold text-gray-900">
                          ${profitData.shippingCost.toFixed(2)}
                        </span>
                      </div>

                      <Separator />

                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">Total Costs</span>
                        <span className="font-bold text-gray-900">
                          ${profitData.totalCosts.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Tips Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5" />
                  Profit Analysis Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">What makes a product profitable?</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• Target profit margins of 15-25% or higher</li>
                      <li>• Factor in return costs and customer service time</li>
                      <li>• Consider Amazon Prime shipping vs. standard shipping</li>
                      <li>• Account for potential price fluctuations</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Fee Considerations</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• eBay fees vary by category (8-15%)</li>
                      <li>• PayPal fees: 3.49% + $0.49 per transaction</li>
                      <li>• Consider eBay Store subscription for lower fees</li>
                      <li>• Factor in potential promotional listing fees</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
