import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Monitor, 
  Bell, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  Clock,
  Search,
  Settings,
  Activity,
  Eye,
  EyeOff
} from "lucide-react";
import { Product, MonitoringAlert } from "@shared/schema";

export default function Monitoring() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch monitoring stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/monitoring/stats"],
  });

  // Fetch user's products
  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Fetch monitoring alerts
  const { data: alerts = [], isLoading: alertsLoading } = useQuery<MonitoringAlert[]>({
    queryKey: ["/api/monitoring/alerts"],
  });

  // Toggle monitoring mutation
  const toggleMonitoringMutation = useMutation({
    mutationFn: async ({ productId, isMonitored }: { productId: number; isMonitored: boolean }) => {
      await apiRequest("POST", `/api/monitoring/toggle/${productId}`, { isMonitored });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/monitoring/stats"] });
      toast({
        title: "Monitoring updated",
        description: "Product monitoring status has been updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update monitoring",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mark alert as read mutation
  const markAlertReadMutation = useMutation({
    mutationFn: async (alertId: number) => {
      await apiRequest("PATCH", `/api/monitoring/alerts/${alertId}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/monitoring/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/monitoring/stats"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to mark alert as read",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter products
  const filteredProducts = products.filter(product =>
    product.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const monitoredProducts = filteredProducts.filter(p => p.isMonitored);
  const unreadAlerts = alerts.filter((alert: any) => !alert.isRead);

  const getAlertIcon = (alertType: string) => {
    switch (alertType) {
      case 'price_drop':
        return <TrendingDown className="h-4 w-4 text-green-600" />;
      case 'price_increase':
        return <TrendingUp className="h-4 w-4 text-red-600" />;
      case 'out_of_stock':
        return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      default:
        return <Bell className="h-4 w-4 text-blue-600" />;
    }
  };

  const getAlertMessage = (alert: any) => {
    switch (alert.alertType) {
      case 'price_drop':
        return `Price dropped from $${alert.oldValue} to $${alert.newValue}`;
      case 'price_increase':
        return `Price increased from $${alert.oldValue} to $${alert.newValue}`;
      case 'out_of_stock':
        return `Product went out of stock`;
      default:
        return `Alert: ${alert.newValue}`;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Price Monitoring</h1>
              <p className="text-sm text-gray-500">Track price changes and get alerts for your products</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Activity className={`h-4 w-4 ${stats?.activeMonitoring ? 'text-green-600' : 'text-gray-400'}`} />
                <span className="text-sm text-gray-600">
                  {stats?.activeMonitoring ? 'Monitoring Active' : 'Monitoring Inactive'}
                </span>
              </div>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-8 space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Total Products</p>
                    {statsLoading ? (
                      <Skeleton className="h-6 w-12 mt-1" />
                    ) : (
                      <p className="text-2xl font-bold text-gray-900">{stats?.totalProducts || 0}</p>
                    )}
                  </div>
                  <Monitor className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Monitored</p>
                    {statsLoading ? (
                      <Skeleton className="h-6 w-12 mt-1" />
                    ) : (
                      <p className="text-2xl font-bold text-primary">{stats?.monitoredProducts || 0}</p>
                    )}
                  </div>
                  <Eye className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Unread Alerts</p>
                    {statsLoading ? (
                      <Skeleton className="h-6 w-12 mt-1" />
                    ) : (
                      <p className="text-2xl font-bold text-orange-600">{stats?.unreadAlerts || 0}</p>
                    )}
                  </div>
                  <Bell className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Status</p>
                    <p className={`text-sm font-semibold ${stats?.activeMonitoring ? 'text-green-600' : 'text-gray-500'}`}>
                      {stats?.activeMonitoring ? 'Active' : 'Inactive'}
                    </p>
                  </div>
                  <Activity className={`h-8 w-8 ${stats?.activeMonitoring ? 'text-green-600' : 'text-gray-400'}`} />
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="products" className="space-y-6">
            <TabsList>
              <TabsTrigger value="products">Products ({monitoredProducts.length})</TabsTrigger>
              <TabsTrigger value="alerts">Alerts ({unreadAlerts.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="products" className="space-y-6">
              {/* Search */}
              <Card>
                <CardContent className="p-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Products List */}
              <Card>
                <CardHeader>
                  <CardTitle>Product Monitoring</CardTitle>
                </CardHeader>
                <CardContent>
                  {productsLoading ? (
                    <div className="space-y-4">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                          <div className="flex items-center space-x-4">
                            <Skeleton className="w-12 h-12" />
                            <div className="space-y-2">
                              <Skeleton className="h-4 w-48" />
                              <Skeleton className="h-3 w-32" />
                            </div>
                          </div>
                          <Skeleton className="h-6 w-12" />
                        </div>
                      ))}
                    </div>
                  ) : filteredProducts.length > 0 ? (
                    <div className="space-y-4">
                      {filteredProducts.map((product) => (
                        <div key={product.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:shadow-sm transition-shadow">
                          <div className="flex items-center space-x-4 flex-1">
                            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                              {product.images && product.images.length > 0 ? (
                                <img
                                  src={product.images[0]}
                                  alt={product.title}
                                  className="w-full h-full object-cover rounded-lg"
                                />
                              ) : (
                                <Monitor className="h-6 w-6 text-gray-600" />
                              )}
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <h3 className="font-medium text-gray-900 line-clamp-1">
                                {product.title}
                              </h3>
                              <div className="flex items-center space-x-4 mt-1 text-sm text-gray-500">
                                <span>Price: ${parseFloat(product.amazonPrice).toFixed(2)}</span>
                                <span className="flex items-center">
                                  <Clock className="h-3 w-3 mr-1" />
                                  Updated: {new Date(product.updatedAt).toLocaleDateString()}
                                </span>
                              </div>
                              {product.isMonitored && (
                                <Badge variant="outline" className="mt-2 text-xs">
                                  <Eye className="h-3 w-3 mr-1" />
                                  Monitoring
                                </Badge>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-6">
                            <div className="text-right">
                              <p className="text-sm text-gray-500">Current Price</p>
                              <p className="font-semibold text-gray-900">
                                ${parseFloat(product.amazonPrice).toFixed(2)}
                              </p>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <Switch
                                checked={product.isMonitored}
                                onCheckedChange={(checked) => {
                                  toggleMonitoringMutation.mutate({
                                    productId: product.id,
                                    isMonitored: checked,
                                  });
                                }}
                                disabled={toggleMonitoringMutation.isPending}
                              />
                              <span className="text-sm text-gray-600">
                                {product.isMonitored ? 'On' : 'Off'}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Monitor className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        {searchQuery ? "No products found" : "No products to monitor"}
                      </h3>
                      <p className="text-gray-500 mb-4">
                        {searchQuery 
                          ? "Try adjusting your search criteria."
                          : "Start by scraping some products to enable monitoring."
                        }
                      </p>
                      {!searchQuery && (
                        <Button onClick={() => window.location.href = "/scraper"}>
                          Start Scraping Products
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="alerts" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Alerts</CardTitle>
                </CardHeader>
                <CardContent>
                  {alertsLoading ? (
                    <div className="space-y-4">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="flex items-start space-x-3 p-4 border border-gray-200 rounded-lg">
                          <Skeleton className="w-8 h-8" />
                          <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-3 w-1/2" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : alerts.length > 0 ? (
                    <div className="space-y-4">
                      {alerts.map((alert: any) => (
                        <div
                          key={alert.id}
                          className={`flex items-start space-x-3 p-4 border rounded-lg transition-colors ${
                            alert.isRead ? 'border-gray-200 bg-white' : 'border-blue-200 bg-blue-50'
                          }`}
                        >
                          <div className="flex-shrink-0 mt-1">
                            {getAlertIcon(alert.alertType)}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <h4 className="font-medium text-gray-900 line-clamp-1">
                                Product Alert
                              </h4>
                              <span className="text-xs text-gray-500">
                                {new Date(alert.createdAt).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">
                              {getAlertMessage(alert)}
                            </p>
                            <div className="flex items-center space-x-2 mt-2">
                              <Badge
                                variant={alert.alertType === 'price_drop' ? 'default' : 'secondary'}
                                className={
                                  alert.alertType === 'price_drop' 
                                    ? 'bg-green-100 text-green-800' 
                                    : alert.alertType === 'price_increase'
                                    ? 'bg-red-100 text-red-800'
                                    : 'bg-orange-100 text-orange-800'
                                }
                              >
                                {alert.alertType.replace('_', ' ').toUpperCase()}
                              </Badge>
                              {!alert.isRead && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => markAlertReadMutation.mutate(alert.id)}
                                  disabled={markAlertReadMutation.isPending}
                                  className="text-xs"
                                >
                                  Mark as Read
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No alerts yet</h3>
                      <p className="text-gray-500 mb-4">
                        Enable monitoring on your products to receive price alerts.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}
