import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/sidebar";
import { ProductCard } from "@/components/product-card";
import { ListingModal } from "@/components/listing-modal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Search, Plus, AlertCircle, ExternalLink } from "lucide-react";
import { Product } from "@shared/schema";

export default function Scraper() {
  const { toast } = useToast();
  const [scrapeInput, setScrapeInput] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isListingModalOpen, setIsListingModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("scrape");

  // Fetch user's products
  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Scrape mutation
  const scrapeMutation = useMutation({
    mutationFn: async (input: string) => {
      const res = await apiRequest("POST", "/api/scrape-amazon", { input });
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Product scraped successfully!",
        description: `Found: ${data.product.title}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setScrapeInput("");
    },
    onError: (error: Error) => {
      toast({
        title: "Scraping failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Search mutation
  const searchMutation = useMutation({
    mutationFn: async (keyword: string) => {
      const res = await apiRequest("POST", "/api/search-amazon", { keyword, limit: 10 });
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Search failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleScrape = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scrapeInput.trim()) return;
    
    if (scrapeInput.startsWith('http')) {
      scrapeMutation.mutate(scrapeInput);
    } else {
      searchMutation.mutate(scrapeInput);
      setActiveTab("results");
    }
  };

  const handleListOnEbay = (product: Product) => {
    setSelectedProduct(product);
    setIsListingModalOpen(true);
  };

  const handleViewDetails = (product: Product) => {
    // Open product details modal or navigate to details page
    console.log("View details for:", product);
  };

  const popularKeywords = [
    "wireless headphones",
    "kitchen gadgets",
    "phone accessories",
    "bluetooth speakers",
    "fitness tracker",
    "led lights",
    "car accessories",
    "home decor"
  ];

  const profitableProducts = products.filter(p => parseFloat(p.estimatedProfit || '0') > 0);
  const recentProducts = products.slice(0, 12);

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Product Scraper</h1>
              <p className="text-sm text-gray-500">Find profitable products on Amazon to list on eBay</p>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-8 space-y-8">
          {/* Scraper Interface */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Amazon Product Scraper
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handleScrape} className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Enter Amazon URL or search keyword..."
                      value={scrapeInput}
                      onChange={(e) => setScrapeInput(e.target.value)}
                      disabled={scrapeMutation.isPending || searchMutation.isPending}
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={!scrapeInput.trim() || scrapeMutation.isPending || searchMutation.isPending}
                  >
                    {scrapeMutation.isPending || searchMutation.isPending ? (
                      <>
                        <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                        {scrapeInput.startsWith('http') ? 'Scraping...' : 'Searching...'}
                      </>
                    ) : (
                      <>
                        <Search className="h-4 w-4 mr-2" />
                        {scrapeInput.startsWith('http') ? 'Scrape' : 'Search'}
                      </>
                    )}
                  </Button>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600 mb-2">Popular keywords:</p>
                  <div className="flex flex-wrap gap-2">
                    {popularKeywords.map((keyword) => (
                      <Badge
                        key={keyword}
                        variant="secondary"
                        className="cursor-pointer hover:bg-gray-200"
                        onClick={() => setScrapeInput(keyword)}
                      >
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </div>
              </form>

              {/* Help Text */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-blue-900 mb-1">How to use:</p>
                    <ul className="text-blue-800 space-y-1">
                      <li>• Paste an Amazon product URL to scrape specific product details</li>
                      <li>• Enter keywords to search for products and see multiple results</li>
                      <li>• Look for products with high profit margins (green indicators)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Search Results */}
          {searchMutation.data && (
            <Card>
              <CardHeader>
                <CardTitle>Search Results</CardTitle>
              </CardHeader>
              <CardContent>
                {searchMutation.data.length > 0 ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {searchMutation.data.map((product: any, index: number) => (
                      <div key={index} className="border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow">
                        <div className="aspect-square bg-gray-100 rounded-lg mb-4 flex items-center justify-center overflow-hidden">
                          {product.images && product.images.length > 0 ? (
                            <img
                              src={product.images[0]}
                              alt={product.title}
                              className="w-full h-full object-cover rounded-lg"
                            />
                          ) : (
                            <div className="w-full h-full bg-gray-200 rounded-lg flex items-center justify-center">
                              <span className="text-gray-400 text-sm">No Image</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="space-y-3">
                          <h3 className="font-medium text-gray-900 line-clamp-2 text-sm leading-tight">
                            {product.title}
                          </h3>
                          
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-gray-500">Amazon Price</span>
                              <span className="font-semibold text-gray-900">
                                ${product.price.toFixed(2)}
                              </span>
                            </div>
                            
                            {product.ebayEstimatedPrice && (
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-gray-500">eBay Est.</span>
                                <span className="font-semibold text-gray-900">
                                  ${product.ebayEstimatedPrice.toFixed(2)}
                                </span>
                              </div>
                            )}
                            
                            {product.estimatedProfit !== undefined && (
                              <div className="flex items-center justify-between">
                                <span className="text-sm font-medium text-gray-700">Profit</span>
                                <Badge
                                  variant={product.isProfitable ? "default" : "destructive"}
                                  className={
                                    product.isProfitable 
                                      ? "bg-green-100 text-green-800 hover:bg-green-100" 
                                      : "bg-red-100 text-red-800 hover:bg-red-100"
                                  }
                                >
                                  {product.estimatedProfit >= 0 ? '+' : ''}${product.estimatedProfit.toFixed(2)}
                                </Badge>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex gap-2 pt-2">
                            <Button
                              size="sm"
                              className="flex-1 text-xs"
                              onClick={() => scrapeMutation.mutate(`https://www.amazon.com/dp/${product.asin}`)}
                              disabled={scrapeMutation.isPending}
                            >
                              {scrapeMutation.isPending ? "Adding..." : "Add to Products"}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => window.open(`https://www.amazon.com/dp/${product.asin}`, '_blank')}
                              className="px-3"
                            >
                              <ExternalLink className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-gray-500 py-8">No products found for your search.</p>
                )}
              </CardContent>
            </Card>
          )}

          {/* Scraped Products */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="scrape">All Products</TabsTrigger>
              <TabsTrigger value="profitable">Profitable Only</TabsTrigger>
            </TabsList>
            
            <TabsContent value="scrape" className="mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Your Products ({products.length})</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  {productsLoading ? (
                    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                      {[...Array(6)].map((_, i) => (
                        <Card key={i}>
                          <CardContent className="p-4">
                            <Skeleton className="aspect-square w-full mb-4" />
                            <Skeleton className="h-4 w-full mb-2" />
                            <Skeleton className="h-4 w-3/4 mb-4" />
                            <div className="space-y-2">
                              <Skeleton className="h-3 w-full" />
                              <Skeleton className="h-3 w-full" />
                              <Skeleton className="h-8 w-full" />
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : recentProducts.length > 0 ? (
                    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                      {recentProducts.map((product) => (
                        <ProductCard
                          key={product.id}
                          product={product}
                          onViewDetails={handleViewDetails}
                          onListOnEbay={handleListOnEbay}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No products scraped yet</h3>
                      <p className="text-gray-500 mb-4">
                        Start by entering an Amazon URL or search keyword above.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="profitable" className="mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Profitable Products ({profitableProducts.length})</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  {profitableProducts.length > 0 ? (
                    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                      {profitableProducts.map((product) => (
                        <ProductCard
                          key={product.id}
                          product={product}
                          onViewDetails={handleViewDetails}
                          onListOnEbay={handleListOnEbay}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Plus className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No profitable products yet</h3>
                      <p className="text-gray-500 mb-4">
                        Keep scraping products to find profitable opportunities.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>

      <ListingModal
        product={selectedProduct}
        open={isListingModalOpen}
        onOpenChange={setIsListingModalOpen}
      />
    </div>
  );
}
