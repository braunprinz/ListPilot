import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  ebayAccessToken: text("ebay_access_token"),
  ebayRefreshToken: text("ebay_refresh_token"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  asin: text("asin").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  images: jsonb("images").$type<string[]>().notNull().default([]),
  amazonPrice: decimal("amazon_price", { precision: 10, scale: 2 }).notNull(),
  amazonUrl: text("amazon_url").notNull(),
  ebayEstimatedPrice: decimal("ebay_estimated_price", { precision: 10, scale: 2 }),
  estimatedProfit: decimal("estimated_profit", { precision: 10, scale: 2 }),
  rating: decimal("rating", { precision: 3, scale: 2 }),
  reviewCount: integer("review_count"),
  category: text("category"),
  brand: text("brand"),
  isMonitored: boolean("is_monitored").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const ebayListings = pgTable("ebay_listings", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  userId: integer("user_id").notNull().references(() => users.id),
  ebayItemId: text("ebay_item_id"),
  listingTitle: text("listing_title").notNull(),
  listingPrice: decimal("listing_price", { precision: 10, scale: 2 }).notNull(),
  buyItNowPrice: decimal("buy_it_now_price", { precision: 10, scale: 2 }),
  condition: text("condition").notNull(),
  listingStatus: text("listing_status").notNull().default("draft"), // draft, active, sold, ended
  ebayCategory: text("ebay_category"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const priceHistory = pgTable("price_history", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  availability: text("availability").notNull(),
  checkedAt: timestamp("checked_at").defaultNow().notNull(),
});

export const monitoringAlerts = pgTable("monitoring_alerts", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  userId: integer("user_id").notNull().references(() => users.id),
  alertType: text("alert_type").notNull(), // price_drop, price_increase, out_of_stock
  oldValue: text("old_value"),
  newValue: text("new_value"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  products: many(products),
  ebayListings: many(ebayListings),
  monitoringAlerts: many(monitoringAlerts),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  user: one(users, {
    fields: [products.userId],
    references: [users.id],
  }),
  ebayListings: many(ebayListings),
  priceHistory: many(priceHistory),
  monitoringAlerts: many(monitoringAlerts),
}));

export const ebayListingsRelations = relations(ebayListings, ({ one }) => ({
  product: one(products, {
    fields: [ebayListings.productId],
    references: [products.id],
  }),
  user: one(users, {
    fields: [ebayListings.userId],
    references: [users.id],
  }),
}));

export const priceHistoryRelations = relations(priceHistory, ({ one }) => ({
  product: one(products, {
    fields: [priceHistory.productId],
    references: [products.id],
  }),
}));

export const monitoringAlertsRelations = relations(monitoringAlerts, ({ one }) => ({
  product: one(products, {
    fields: [monitoringAlerts.productId],
    references: [products.id],
  }),
  user: one(users, {
    fields: [monitoringAlerts.userId],
    references: [users.id],
  }),
}));

// Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEbayListingSchema = createInsertSchema(ebayListings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPriceHistorySchema = createInsertSchema(priceHistory).omit({
  id: true,
  checkedAt: true,
});

export const insertMonitoringAlertSchema = createInsertSchema(monitoringAlerts).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type EbayListing = typeof ebayListings.$inferSelect;
export type InsertEbayListing = z.infer<typeof insertEbayListingSchema>;
export type PriceHistory = typeof priceHistory.$inferSelect;
export type InsertPriceHistory = z.infer<typeof insertPriceHistorySchema>;
export type MonitoringAlert = typeof monitoringAlerts.$inferSelect;
export type InsertMonitoringAlert = z.infer<typeof insertMonitoringAlertSchema>;
