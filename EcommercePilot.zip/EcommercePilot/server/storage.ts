import { 
  users, 
  products, 
  ebayListings, 
  priceHistory, 
  monitoringAlerts,
  type User, 
  type InsertUser,
  type Product,
  type InsertProduct,
  type EbayListing,
  type InsertEbayListing,
  type PriceHistory,
  type InsertPriceHistory,
  type MonitoringAlert,
  type InsertMonitoringAlert
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;

  // Product methods
  getProduct(id: number): Promise<Product | undefined>;
  getProductsByUser(userId: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // eBay listing methods
  getEbayListing(id: number): Promise<EbayListing | undefined>;
  getEbayListingsByUser(userId: number): Promise<EbayListing[]>;
  getEbayListingsByProduct(productId: number): Promise<EbayListing[]>;
  createEbayListing(listing: InsertEbayListing): Promise<EbayListing>;
  updateEbayListing(id: number, updates: Partial<EbayListing>): Promise<EbayListing | undefined>;
  deleteEbayListing(id: number): Promise<boolean>;

  // Price history methods
  getPriceHistory(productId: number): Promise<PriceHistory[]>;
  addPriceHistory(priceHistory: InsertPriceHistory): Promise<PriceHistory>;

  // Monitoring alerts methods
  getMonitoringAlerts(userId: number): Promise<MonitoringAlert[]>;
  getUnreadMonitoringAlerts(userId: number): Promise<MonitoringAlert[]>;
  createMonitoringAlert(alert: InsertMonitoringAlert): Promise<MonitoringAlert>;
  markAlertAsRead(id: number): Promise<boolean>;

  // Session store
  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  // Product methods
  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async getProductsByUser(userId: number): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(eq(products.userId, userId))
      .orderBy(desc(products.createdAt));
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db
      .insert(products)
      .values(product)
      .returning();
    return newProduct;
  }

  async updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined> {
    const [product] = await db
      .update(products)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(products.id, id))
      .returning();
    return product || undefined;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id));
    return (result.rowCount || 0) > 0;
  }

  // eBay listing methods
  async getEbayListing(id: number): Promise<EbayListing | undefined> {
    const [listing] = await db.select().from(ebayListings).where(eq(ebayListings.id, id));
    return listing || undefined;
  }

  async getEbayListingsByUser(userId: number): Promise<EbayListing[]> {
    return await db
      .select()
      .from(ebayListings)
      .where(eq(ebayListings.userId, userId))
      .orderBy(desc(ebayListings.createdAt));
  }

  async getEbayListingsByProduct(productId: number): Promise<EbayListing[]> {
    return await db
      .select()
      .from(ebayListings)
      .where(eq(ebayListings.productId, productId))
      .orderBy(desc(ebayListings.createdAt));
  }

  async createEbayListing(listing: InsertEbayListing): Promise<EbayListing> {
    const [newListing] = await db
      .insert(ebayListings)
      .values({
        ...listing,
        updatedAt: new Date(),
      })
      .returning();
    return newListing;
  }

  async updateEbayListing(id: number, updates: Partial<EbayListing>): Promise<EbayListing | undefined> {
    const [listing] = await db
      .update(ebayListings)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(ebayListings.id, id))
      .returning();
    return listing || undefined;
  }

  async deleteEbayListing(id: number): Promise<boolean> {
    const result = await db.delete(ebayListings).where(eq(ebayListings.id, id));
    return result.rowCount > 0;
  }

  // Price history methods
  async getPriceHistory(productId: number): Promise<PriceHistory[]> {
    return await db
      .select()
      .from(priceHistory)
      .where(eq(priceHistory.productId, productId))
      .orderBy(desc(priceHistory.checkedAt));
  }

  async addPriceHistory(priceHistoryData: InsertPriceHistory): Promise<PriceHistory> {
    const [newPriceHistory] = await db
      .insert(priceHistory)
      .values(priceHistoryData)
      .returning();
    return newPriceHistory;
  }

  // Monitoring alerts methods
  async getMonitoringAlerts(userId: number): Promise<MonitoringAlert[]> {
    return await db
      .select()
      .from(monitoringAlerts)
      .where(eq(monitoringAlerts.userId, userId))
      .orderBy(desc(monitoringAlerts.createdAt));
  }

  async getUnreadMonitoringAlerts(userId: number): Promise<MonitoringAlert[]> {
    return await db
      .select()
      .from(monitoringAlerts)
      .where(and(
        eq(monitoringAlerts.userId, userId),
        eq(monitoringAlerts.isRead, false)
      ))
      .orderBy(desc(monitoringAlerts.createdAt));
  }

  async createMonitoringAlert(alert: InsertMonitoringAlert): Promise<MonitoringAlert> {
    const [newAlert] = await db
      .insert(monitoringAlerts)
      .values(alert)
      .returning();
    return newAlert;
  }

  async markAlertAsRead(id: number): Promise<boolean> {
    const result = await db
      .update(monitoringAlerts)
      .set({ isRead: true })
      .where(eq(monitoringAlerts.id, id));
    return result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();
