import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { AmazonScraper } from "./services/scraper";
import { ProfitCalculator } from "./services/profit-calculator";
import { monitoringService } from "./services/monitoring";
import { insertProductSchema, insertEbayListingSchema } from "@shared/schema";

const scraper = new AmazonScraper();
const profitCalculator = new ProfitCalculator();

function requireAuth(req: any, res: any, next: any) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
}

export function registerRoutes(app: Express): Server {
  // Setup authentication routes
  setupAuth(app);

  // Amazon scraping routes
  app.post("/api/scrape-amazon", requireAuth, async (req, res) => {
    try {
      const { input } = req.body; // URL or keyword
      
      if (!input) {
        return res.status(400).json({ message: "URL or keyword is required" });
      }

      const productData = await scraper.scrapeProduct(input);
      
      // Calculate estimated eBay price and profit
      const ebayEstimatedPrice = await profitCalculator.estimateEbayPrice(
        productData.title, 
        productData.category
      );
      
      const profitData = profitCalculator.calculateProfit(
        productData.price,
        ebayEstimatedPrice * productData.price // Apply multiplier to Amazon price
      );

      // Save product to database
      const product = await storage.createProduct({
        userId: req.user.id,
        asin: productData.asin,
        title: productData.title,
        description: productData.description,
        images: productData.images,
        amazonPrice: productData.price.toString(),
        amazonUrl: req.body.input.startsWith('http') ? req.body.input : `https://www.amazon.com/dp/${productData.asin}`,
        ebayEstimatedPrice: profitData.ebayEstimatedPrice.toString(),
        estimatedProfit: profitData.estimatedProfit.toString(),
        rating: productData.rating?.toString(),
        reviewCount: productData.reviewCount,
        category: productData.category,
        brand: productData.brand,
      });

      res.json({
        product,
        profitAnalysis: profitData,
        scrapedData: productData,
      });

    } catch (error) {
      console.error("Scraping error:", error);
      res.status(500).json({ message: error.message || "Failed to scrape product" });
    }
  });

  // Search Amazon products
  app.post("/api/search-amazon", requireAuth, async (req, res) => {
    try {
      const { keyword, limit = 10 } = req.body;
      
      if (!keyword) {
        return res.status(400).json({ message: "Search keyword is required" });
      }

      const products = await scraper.searchProducts(keyword, limit);
      
      // Calculate profit for each product
      const productsWithProfit = await Promise.all(
        products.map(async (product) => {
          const ebayEstimatedPrice = await profitCalculator.estimateEbayPrice(
            product.title, 
            product.category
          );
          
          const profitData = profitCalculator.calculateProfit(
            product.price,
            ebayEstimatedPrice * product.price
          );

          return {
            ...product,
            ebayEstimatedPrice: profitData.ebayEstimatedPrice,
            estimatedProfit: profitData.estimatedProfit,
            isProfitable: profitData.isProfitable,
          };
        })
      );

      res.json(productsWithProfit);

    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ message: error.message || "Failed to search products" });
    }
  });

  // Get user's products
  app.get("/api/products", requireAuth, async (req, res) => {
    try {
      const products = await storage.getProductsByUser(req.user.id);
      res.json(products);
    } catch (error) {
      console.error("Get products error:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Get single product
  app.get("/api/products/:id", requireAuth, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      
      if (!product || product.userId !== req.user.id) {
        return res.status(404).json({ message: "Product not found" });
      }

      res.json(product);
    } catch (error) {
      console.error("Get product error:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Update product
  app.patch("/api/products/:id", requireAuth, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const updates = req.body;
      
      // Verify ownership
      const existingProduct = await storage.getProduct(productId);
      if (!existingProduct || existingProduct.userId !== req.user.id) {
        return res.status(404).json({ message: "Product not found" });
      }

      const product = await storage.updateProduct(productId, updates);
      res.json(product);
    } catch (error) {
      console.error("Update product error:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  // Delete product
  app.delete("/api/products/:id", requireAuth, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      
      // Verify ownership
      const existingProduct = await storage.getProduct(productId);
      if (!existingProduct || existingProduct.userId !== req.user.id) {
        return res.status(404).json({ message: "Product not found" });
      }

      await storage.deleteProduct(productId);
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      console.error("Delete product error:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Profit calculation route
  app.post("/api/check-ebay-profit", requireAuth, async (req, res) => {
    try {
      const { amazonPrice, ebayPrice, shippingCost, customEbayFeeRate } = req.body;
      
      if (!amazonPrice || !ebayPrice) {
        return res.status(400).json({ message: "Amazon price and eBay price are required" });
      }

      const profitData = profitCalculator.calculateProfit(
        parseFloat(amazonPrice),
        parseFloat(ebayPrice),
        shippingCost ? parseFloat(shippingCost) : undefined,
        customEbayFeeRate ? parseFloat(customEbayFeeRate) : undefined
      );

      res.json(profitData);
    } catch (error) {
      console.error("Profit calculation error:", error);
      res.status(500).json({ message: "Failed to calculate profit" });
    }
  });

  // eBay listing routes
  app.post("/api/list-on-ebay", requireAuth, async (req, res) => {
    try {
      const listingData = insertEbayListingSchema.parse({
        ...req.body,
        userId: req.user.id,
      });

      // Verify product ownership
      const product = await storage.getProduct(listingData.productId);
      if (!product || product.userId !== req.user.id) {
        return res.status(404).json({ message: "Product not found" });
      }

      // In a real implementation, you would integrate with eBay's API here
      // For now, we'll just create a draft listing
      const listing = await storage.createEbayListing({
        ...listingData,
        listingStatus: "draft", // Would be "active" when actually posted to eBay
      });

      res.json(listing);
    } catch (error) {
      console.error("eBay listing error:", error);
      res.status(500).json({ message: "Failed to create eBay listing" });
    }
  });

  // Get user's eBay listings
  app.get("/api/ebay-listings", requireAuth, async (req, res) => {
    try {
      const listings = await storage.getEbayListingsByUser(req.user.id);
      res.json(listings);
    } catch (error) {
      console.error("Get eBay listings error:", error);
      res.status(500).json({ message: "Failed to fetch eBay listings" });
    }
  });

  // Update eBay listing
  app.patch("/api/ebay-listings/:id", requireAuth, async (req, res) => {
    try {
      const listingId = parseInt(req.params.id);
      const updates = req.body;
      
      // Verify ownership
      const existingListing = await storage.getEbayListing(listingId);
      if (!existingListing || existingListing.userId !== req.user.id) {
        return res.status(404).json({ message: "Listing not found" });
      }

      const listing = await storage.updateEbayListing(listingId, updates);
      res.json(listing);
    } catch (error) {
      console.error("Update eBay listing error:", error);
      res.status(500).json({ message: "Failed to update eBay listing" });
    }
  });

  // Monitoring routes
  app.get("/api/monitoring/stats", requireAuth, async (req, res) => {
    try {
      const stats = await monitoringService.getMonitoringStats(req.user.id);
      res.json(stats);
    } catch (error) {
      console.error("Monitoring stats error:", error);
      res.status(500).json({ message: "Failed to fetch monitoring stats" });
    }
  });

  app.post("/api/monitoring/toggle/:productId", requireAuth, async (req, res) => {
    try {
      const productId = parseInt(req.params.productId);
      const { isMonitored } = req.body;
      
      // Verify ownership
      const product = await storage.getProduct(productId);
      if (!product || product.userId !== req.user.id) {
        return res.status(404).json({ message: "Product not found" });
      }

      const success = await monitoringService.toggleProductMonitoring(productId, isMonitored);
      
      if (success) {
        res.json({ message: "Monitoring status updated successfully" });
      } else {
        res.status(500).json({ message: "Failed to update monitoring status" });
      }
    } catch (error) {
      console.error("Toggle monitoring error:", error);
      res.status(500).json({ message: "Failed to toggle monitoring" });
    }
  });

  app.get("/api/monitoring/alerts", requireAuth, async (req, res) => {
    try {
      const alerts = await storage.getMonitoringAlerts(req.user.id);
      res.json(alerts);
    } catch (error) {
      console.error("Get alerts error:", error);
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.patch("/api/monitoring/alerts/:id/read", requireAuth, async (req, res) => {
    try {
      const alertId = parseInt(req.params.id);
      const success = await storage.markAlertAsRead(alertId);
      
      if (success) {
        res.json({ message: "Alert marked as read" });
      } else {
        res.status(404).json({ message: "Alert not found" });
      }
    } catch (error) {
      console.error("Mark alert read error:", error);
      res.status(500).json({ message: "Failed to mark alert as read" });
    }
  });

  // Price history route
  app.get("/api/products/:id/price-history", requireAuth, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      
      // Verify ownership
      const product = await storage.getProduct(productId);
      if (!product || product.userId !== req.user.id) {
        return res.status(404).json({ message: "Product not found" });
      }

      const priceHistory = await storage.getPriceHistory(productId);
      res.json(priceHistory);
    } catch (error) {
      console.error("Price history error:", error);
      res.status(500).json({ message: "Failed to fetch price history" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", requireAuth, async (req, res) => {
    try {
      const products = await storage.getProductsByUser(req.user.id);
      const listings = await storage.getEbayListingsByUser(req.user.id);
      const alerts = await storage.getUnreadMonitoringAlerts(req.user.id);

      const profitableProducts = products.filter(p => {
        const profit = parseFloat(p.estimatedProfit || '0');
        return profit > 0;
      });

      const activeListings = listings.filter(l => l.listingStatus === 'active');
      
      const totalProfit = profitableProducts.reduce((sum, product) => {
        return sum + parseFloat(product.estimatedProfit || '0');
      }, 0);

      const stats = {
        totalProducts: products.length,
        profitableProducts: profitableProducts.length,
        activeListings: activeListings.length,
        totalProfit: Math.round(totalProfit * 100) / 100,
        unreadAlerts: alerts.length,
      };

      res.json(stats);
    } catch (error) {
      console.error("Dashboard stats error:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
