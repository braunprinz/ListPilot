export interface ProfitCalculation {
  amazonPrice: number;
  ebayEstimatedPrice: number;
  ebayFees: number;
  paypalFees: number;
  shippingCost: number;
  totalCosts: number;
  estimatedProfit: number;
  profitMargin: number;
  isProfitable: boolean;
}

export class ProfitCalculator {
  private readonly EBAY_FINAL_VALUE_FEE = 0.129; // 12.9% for most categories
  private readonly PAYPAL_FEE = 0.0349; // 3.49% + $0.49 per transaction
  private readonly PAYPAL_FIXED_FEE = 0.49;
  private readonly DEFAULT_SHIPPING_COST = 5.99;

  calculateProfit(
    amazonPrice: number,
    ebayEstimatedPrice: number,
    shippingCost: number = this.DEFAULT_SHIPPING_COST,
    customEbayFeeRate?: number
  ): ProfitCalculation {
    const ebayFeeRate = customEbayFeeRate || this.EBAY_FINAL_VALUE_FEE;
    
    // Calculate fees
    const ebayFees = ebayEstimatedPrice * ebayFeeRate;
    const paypalFees = (ebayEstimatedPrice * this.PAYPAL_FEE) + this.PAYPAL_FIXED_FEE;
    
    // Total costs
    const totalCosts = amazonPrice + ebayFees + paypalFees + shippingCost;
    
    // Profit calculation
    const estimatedProfit = ebayEstimatedPrice - totalCosts;
    const profitMargin = (estimatedProfit / ebayEstimatedPrice) * 100;
    
    return {
      amazonPrice,
      ebayEstimatedPrice,
      ebayFees: Math.round(ebayFees * 100) / 100,
      paypalFees: Math.round(paypalFees * 100) / 100,
      shippingCost,
      totalCosts: Math.round(totalCosts * 100) / 100,
      estimatedProfit: Math.round(estimatedProfit * 100) / 100,
      profitMargin: Math.round(profitMargin * 100) / 100,
      isProfitable: estimatedProfit > 0
    };
  }

  async estimateEbayPrice(title: string, category?: string): Promise<number> {
    // This is a simplified estimation. In a real implementation, you would:
    // 1. Use eBay's Browse API to search for similar items
    // 2. Analyze completed listings to get average selling price
    // 3. Apply category-specific markup rules
    
    // For now, we'll use a basic estimation based on keywords and categories
    const baseMultiplier = this.getBaseMultiplier(category);
    const keywordMultiplier = this.getKeywordMultiplier(title);
    
    return baseMultiplier * keywordMultiplier;
  }

  private getBaseMultiplier(category?: string): number {
    if (!category) return 1.3; // Default 30% markup
    
    const categoryMultipliers: { [key: string]: number } = {
      'Electronics': 1.4,
      'Cell Phones & Accessories': 1.35,
      'Computers/Tablets & Networking': 1.3,
      'Home & Garden': 1.45,
      'Health & Beauty': 1.5,
      'Fashion': 1.6,
      'Sports & Outdoors': 1.4,
      'Toys & Hobbies': 1.5,
      'Automotive': 1.35,
      'Books': 1.2,
    };

    for (const [cat, multiplier] of Object.entries(categoryMultipliers)) {
      if (category.toLowerCase().includes(cat.toLowerCase())) {
        return multiplier;
      }
    }

    return 1.3; // Default
  }

  private getKeywordMultiplier(title: string): number {
    const titleLower = title.toLowerCase();
    let multiplier = 1.0;

    // Premium keywords that typically command higher prices
    const premiumKeywords = [
      'premium', 'professional', 'pro', 'deluxe', 'luxury',
      'wireless', 'bluetooth', 'smart', 'digital', 'led',
      'stainless steel', 'organic', 'natural', 'eco-friendly'
    ];

    // Budget keywords that might indicate lower price points
    const budgetKeywords = [
      'basic', 'standard', 'simple', 'budget', 'economy',
      'plastic', 'generic', 'universal'
    ];

    premiumKeywords.forEach(keyword => {
      if (titleLower.includes(keyword)) {
        multiplier += 0.1;
      }
    });

    budgetKeywords.forEach(keyword => {
      if (titleLower.includes(keyword)) {
        multiplier -= 0.05;
      }
    });

    return Math.max(0.8, Math.min(2.0, multiplier)); // Clamp between 0.8 and 2.0
  }

  calculateMinimumProfitPrice(
    amazonPrice: number,
    targetProfitMargin: number = 15, // 15% profit margin
    shippingCost: number = this.DEFAULT_SHIPPING_COST
  ): number {
    // Calculate minimum selling price to achieve target profit margin
    const targetProfitDecimal = targetProfitMargin / 100;
    
    // Formula: sellingPrice = (amazonPrice + shippingCost + paypalFixedFee) / (1 - ebayFeeRate - paypalFeeRate - targetProfitDecimal)
    const denominator = 1 - this.EBAY_FINAL_VALUE_FEE - this.PAYPAL_FEE - targetProfitDecimal;
    const numerator = amazonPrice + shippingCost + this.PAYPAL_FIXED_FEE;
    
    return Math.round((numerator / denominator) * 100) / 100;
  }
}
