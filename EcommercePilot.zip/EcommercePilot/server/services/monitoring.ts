import { storage } from '../storage';
import { AmazonScraper } from './scraper';
import { Product, InsertPriceHistory, InsertMonitoringAlert } from '@shared/schema';

export class MonitoringService {
  private scraper: AmazonScraper;
  private monitoringInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.scraper = new AmazonScraper();
  }

  async startMonitoring(intervalMinutes: number = 30) {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }

    this.monitoringInterval = setInterval(async () => {
      await this.checkAllMonitoredProducts();
    }, intervalMinutes * 60 * 1000);

    console.log(`Monitoring started with ${intervalMinutes} minute intervals`);
  }

  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    console.log('Monitoring stopped');
  }

  async checkAllMonitoredProducts() {
    try {
      // Get all users and their monitored products
      const allUsers = await this.getAllUsersWithMonitoredProducts();
      
      for (const user of allUsers) {
        const monitoredProducts = user.products.filter(p => p.isMonitored);
        
        for (const product of monitoredProducts) {
          await this.checkProduct(product);
        }
      }
    } catch (error) {
      console.error('Error checking monitored products:', error);
    }
  }

  private async getAllUsersWithMonitoredProducts(): Promise<any[]> {
    // This is a simplified version. In a real implementation, you'd need to 
    // modify the storage interface to get users with their monitored products
    // For now, we'll return an empty array as the storage interface doesn't support this
    return [];
  }

  async checkProduct(product: Product) {
    try {
      const currentData = await this.scraper.scrapeProduct(product.amazonUrl);
      const currentPrice = currentData.price;
      const currentAvailability = currentData.availability;

      // Get the last price from history
      const priceHistory = await storage.getPriceHistory(product.id);
      const lastPrice = priceHistory.length > 0 ? parseFloat(priceHistory[0].price) : parseFloat(product.amazonPrice);

      // Add current price to history
      const priceHistoryData: InsertPriceHistory = {
        productId: product.id,
        price: currentPrice.toString(),
        availability: currentAvailability,
      };
      await storage.addPriceHistory(priceHistoryData);

      // Check for significant price changes (more than 5% change)
      const priceChangeThreshold = 0.05; // 5%
      const priceChangePercentage = Math.abs((currentPrice - lastPrice) / lastPrice);

      if (priceChangePercentage > priceChangeThreshold) {
        const alertType = currentPrice > lastPrice ? 'price_increase' : 'price_drop';
        
        const alert: InsertMonitoringAlert = {
          productId: product.id,
          userId: product.userId,
          alertType,
          oldValue: lastPrice.toString(),
          newValue: currentPrice.toString(),
        };

        await storage.createMonitoringAlert(alert);
      }

      // Check for availability changes
      if (currentAvailability.toLowerCase().includes('out of stock') || 
          currentAvailability.toLowerCase().includes('unavailable')) {
        const alert: InsertMonitoringAlert = {
          productId: product.id,
          userId: product.userId,
          alertType: 'out_of_stock',
          oldValue: 'Available',
          newValue: currentAvailability,
        };

        await storage.createMonitoringAlert(alert);
      }

      // Update product with latest information
      await storage.updateProduct(product.id, {
        amazonPrice: currentPrice.toString(),
        updatedAt: new Date(),
      });

      console.log(`Checked product ${product.id}: ${product.title}`);

    } catch (error) {
      console.error(`Error checking product ${product.id}:`, error);
      
      // Create an alert for monitoring error
      const alert: InsertMonitoringAlert = {
        productId: product.id,
        userId: product.userId,
        alertType: 'monitoring_error',
        oldValue: 'Active',
        newValue: `Error: ${error.message}`,
      };

      await storage.createMonitoringAlert(alert);
    }
  }

  async toggleProductMonitoring(productId: number, isMonitored: boolean): Promise<boolean> {
    try {
      const product = await storage.updateProduct(productId, { isMonitored });
      return !!product;
    } catch (error) {
      console.error('Error toggling product monitoring:', error);
      return false;
    }
  }

  async getMonitoringStats(userId: number) {
    try {
      const userProducts = await storage.getProductsByUser(userId);
      const monitoredProducts = userProducts.filter(p => p.isMonitored);
      const alerts = await storage.getUnreadMonitoringAlerts(userId);

      return {
        totalProducts: userProducts.length,
        monitoredProducts: monitoredProducts.length,
        unreadAlerts: alerts.length,
        activeMonitoring: this.monitoringInterval !== null,
      };
    } catch (error) {
      console.error('Error getting monitoring stats:', error);
      return {
        totalProducts: 0,
        monitoredProducts: 0,
        unreadAlerts: 0,
        activeMonitoring: false,
      };
    }
  }
}

// Create a singleton instance
export const monitoringService = new MonitoringService();

// Start monitoring when the service is imported
monitoringService.startMonitoring(30); // Check every 30 minutes
